# NextGen Corp – HR Analytics (SQL)

This folder contains the SQL script used for the
HR Analytics & Workforce Insights case study.

File
- nextgen_hr_analytics.sql  
  Contains table definitions and analytical queries

Tools
- PostgreSQL

Focus Areas
- Employee retention
- Performance analysis
- Salary fairness
