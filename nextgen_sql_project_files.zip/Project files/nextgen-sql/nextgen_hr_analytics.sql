-- ============================================================
-- NextGen Corp – HR Analytics & Workforce Insights
-- Tool: PostgreSQL
--
-- Description:
-- This SQL script contains analytical queries used to evaluate
-- employee retention, performance trends, attendance patterns,
-- and compensation fairness at NextGen Corp.
--
-- Focus Areas:
-- - Employee retention and tenure analysis
-- - Performance distribution across departments
-- - Salary and compensation insights
--
-- Author: Oluwaseun Muyiwa
-- ============================================================



-- ============================================================
-- Employee Retention Analysis
-- ============================================================


--Who are the top 5 highest serving employees?
--by years of service
SELECT 
    e.employee_id,
    e.first_name,
    e.last_name,
    e.job_title,
    d.department_name,
    e.hire_date,
    ROUND(EXTRACT(DAY FROM AGE(CURRENT_DATE, e.hire_date)) / 365, 1) AS years_of_service
FROM employee e
JOIN department d ON e.department_id = d.department_id
ORDER BY years_of_service DESC
LIMIT 5;

--based on earliest hire date
SELECT 
    e.first_name || ' ' || e.last_name AS employee_name,
    d.department_name,
    e.hire_date
FROM employee e
JOIN department d ON e.department_id = d.department_id
ORDER BY e.hire_date ASC
LIMIT 5;

--What is the turnover rate for each department?
SELECT 
    d.department_name,
    COUNT(DISTINCT t.employee_id) AS employees_left,
    COUNT(DISTINCT e.employee_id) AS total_employees,
    ROUND(
        (COUNT(DISTINCT t.employee_id)::DECIMAL / NULLIF(COUNT(DISTINCT e.employee_id), 0)) * 100, 2
    ) AS turnover_rate_percentage
FROM department d
LEFT JOIN employee e ON d.department_id = e.department_id
LEFT JOIN turnover t ON d.department_id = t.department_id
GROUP BY d.department_name
ORDER BY turnover_rate_percentage DESC NULLS LAST;

--Which employees are at risk of leaving based on their performance?
SELECT 
    e.employee_id,
    e.first_name,
    e.last_name,
    d.department_name,
    p.performance_score,
    p.performance_date
FROM performance p
JOIN employee e ON p.employee_id = e.employee_id
JOIN department d ON p.department_id = d.department_id
WHERE p.performance_score < 65
ORDER BY p.performance_score ASC
LIMIT 10;

--What are the main reasons employees are leaving the company?
SELECT 
    reason_for_leaving,
    COUNT(*) AS count_of_leavers,
    ROUND(
        (COUNT(*) * 100.0 / (SELECT COUNT(*) FROM turnover)), 
        2
    ) AS percentage_of_total
FROM turnover
GROUP BY reason_for_leaving
ORDER BY count_of_leavers DESC;


--Performance Analysis

--How many employees has left the company?
SELECT 
    COUNT(DISTINCT employee_id) AS employees_left
FROM turnover;

--by department
SELECT 
    d.department_name,
    COUNT(DISTINCT t.employee_id) AS employees_left
FROM turnover t
JOIN department d ON t.department_id = d.department_id
GROUP BY d.department_name
ORDER BY employees_left DESC;

--How many employees have a performance score of 5.0 / below 3.5?
SELECT 
    SUM(CASE WHEN performance_score = 5.0 THEN 1 ELSE 0 END) AS score_5_count,
    SUM(CASE WHEN performance_score < 3.5 THEN 1 ELSE 0 END) AS below_3_5_count
FROM performance;

--Which department has the most employees with a performance of 5.0 / below 3.5?
SELECT 
    d.department_name,
    SUM(CASE WHEN p.performance_score = 5.0 THEN 1 ELSE 0 END) AS score_5_count,
    SUM(CASE WHEN p.performance_score < 3.5 THEN 1 ELSE 0 END) AS below_3_5_count
FROM performance p
JOIN department d ON p.department_id = d.department_id
GROUP BY d.department_name
ORDER BY below_3_5_count DESC, score_5_count DESC;

--What is the average performance score by department?
SELECT 
    d.department_name,
    ROUND(AVG(p.performance_score), 2) AS average_performance_score
FROM performance p
JOIN department d ON p.department_id = d.department_id
GROUP BY d.department_name
ORDER BY average_performance_score DESC;


--Salary Analysis

--What is the total salary expense for the company?
SELECT 
    ROUND(SUM(s.salary_amount), 2) AS total_salary_expense
FROM salary s;

--What is the average salary by job title?
SELECT 
    e.job_title,
    ROUND(AVG(s.salary_amount), 2) AS average_salary
FROM employee e
JOIN salary s ON e.employee_id = s.employee_id
GROUP BY e.job_title
ORDER BY average_salary DESC;

--How many employees earn above 80,000?
SELECT 
    COUNT(DISTINCT e.employee_id) AS employees_above_80k
FROM employee e
JOIN salary s ON e.employee_id = s.employee_id
WHERE s.salary_amount > 80000;

--By department
SELECT 
    d.department_name,
    COUNT(DISTINCT e.employee_id) AS employees_above_80k
FROM employee e
JOIN salary s ON e.employee_id = s.employee_id
JOIN department d ON e.department_id = d.department_id
WHERE s.salary_amount > 80000
GROUP BY d.department_name
ORDER BY employees_above_80k DESC;

--How does performance correlate with salary across departments?
SELECT 
    d.department_name,
    ROUND(AVG(s.salary_amount), 2) AS avg_salary,
    ROUND(AVG(p.performance_score), 2) AS avg_performance_score
FROM salary s
JOIN performance p ON s.employee_id = p.employee_id
JOIN department d ON s.depaartment_id = d.department_id
GROUP BY d.department_name
ORDER BY avg_salary DESC;

