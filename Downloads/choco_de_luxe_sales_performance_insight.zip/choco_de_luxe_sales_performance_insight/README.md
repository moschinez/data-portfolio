# Choco De Luxe – Sales & Regional Performance Insights

This Tableau dashboard analyses sales data to
identify trends in revenue, profitability, product and team performance.

Tool
- Tableau

Key Focus Areas
- Sales performance & profitability
- Product-level analysis
- Team performance
- Channel and regional revenue distribution
