## Project Overview
This project was completed entirely in Microsoft Excel.

A single workbook was intentionally used to:
- clean and standardise five business datasets
- analyse performance using Pivot Tables and Excel formulas
- deliver an interactive management dashboard

## Workbook Structure
- 5 worksheets: cleaned business data (sales, customers, employees, stock, feedback)
- 1 worksheet: pivot tables for analysis
- 1 worksheet: executive dashboard

This mirrors a typical Excel-based analytics workflow in small to mid-sized organisations.
