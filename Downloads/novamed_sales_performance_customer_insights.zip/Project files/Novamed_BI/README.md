# NovaMed Solutions – Sales Performance & Customer Insights

This Power BI dashboard analyses pharmaceutical sales data to
identify trends in revenue, profitability, product performance,
and customer behaviour.

Tool
- Power BI

Key Focus Areas
- Sales performance & profitability
- Product-level analysis
- Customer segmentation
- Geographic revenue distribution
